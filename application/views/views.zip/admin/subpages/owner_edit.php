<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Owner Edit
    </h1>
    <ol class="breadcrumb" style="display: none">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">UI</a></li>
        <li class="active">General</li>
    </ol>
</section>
<!-- Main content -->
<section class="content">
    <div class="box box-primary">
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form">
            <div class="box-body row">
                <div class="form-group col-xs-6">
                    <label for="exampleInputEmail1">First Name</label>
                    <input type="text" class="form-control" id="first_name" placeholder="First Name" value="<?php echo $owner['first_name']?>">
                </div>

                <div class="form-group col-xs-6">
                    <label for="exampleInputEmail1">Last Name</label>
                    <input type="text" class="form-control" id="last_name" placeholder="Last Name" value="<?php echo $owner['last_name']?>">
                </div>

                <div class="form-group col-xs-6">
                    <label for="exampleInputEmail1">Email</label>
                    <input type="text" class="form-control" id="email" placeholder="Enter email" value="<?php echo $owner['email']?>">
                </div>

                <div class="form-group col-xs-6">
                    <label for="exampleInputEmail1">Password</label>
                    <input type="text" class="form-control" id="password" placeholder="Password" value="<?php echo $owner['password']?>">
                </div>

                <div class="form-group col-xs-6">
                    <label for="exampleInputEmail1">Required Service</label>
                    <select id="req_service" class="form-control">
                        <option value="">Select</option>
                        <option value="Pre-Arrival/Tidy Clean" <?php if($owner['req_service'] == 'Pre-Arrival/Tidy Clean') echo 'selected'?>>Pre-Arrival/Tidy Clean</option>
                        <option value="Mid-Stay Clean" <?php if($owner['req_service'] == 'Mid-Stay Clean') echo 'selected'?>>Mid-Stay Clean</option>
                        <option value="Departure Clean" <?php if($owner['req_service'] == 'Departure Clean') echo 'selected'?>>Departure Clean</option>
                        <option value="Turn Clean" <?php if($owner['req_service'] == 'Turn Clean') echo 'selected'?>>Turn Clean</option>
                        <option value="No Clean Needed" <?php if($owner['req_service'] == 'No Clean Needed') echo 'selected'?>>No Clean Needed</option>
                        <option value="Annual Clean" <?php if($owner['req_service'] == 'Annual Clean') echo 'selected'?>>Annual Clean</option>
                    </select>
                </div>
                <div class="form-group col-xs-6" style="visibility: hidden">
                    <label for="Password">Password</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter email" >
                </div>

                <div class="form-group col-xs-4">
                    <label for="Check In Date">Check In Date</label>
                    <input type="text" class="form-control" id="check_in_date" placeholder="Check In Date" value="<?php echo $owner['check_in_date']?>">
                </div>

                <div class="form-group col-xs-4">
                    <label for="Check Out Date">Check Out Date</label>
                    <input type="text" class="form-control" id="check_out_date" placeholder="Check Out Date" value="<?php echo $owner['check_out_date']?>">
                </div>

                <div class="form-group col-xs-4">
                    <label for="Check Out Time">Check Out Time</label>
                    <input type="text" class="form-control" id="check_out_time" placeholder="Check Out Time" value="<?php echo $owner['check_out_time']?>">
                </div>

                <div class="form-group col-xs-12">
                    <label for="Cleaning Property Address">Cleanning Property Address</label>
                    <input type="email" class="form-control" id="address" placeholder="Address" value="<?php echo $owner['address']?>">
                </div>
                <div class="form-group col-xs-4">
                    <input type="email" class="form-control" id="city" placeholder="City" value="<?php echo $owner['city']?>">
                </div>
                <div class="form-group col-xs-4">
                    <select id="state" class="form-control">
                        <option value="">State</option>
                        <option value="Armed Forces America">Armed Forces America</option>
                        <option value="Armed Forces">Armed Forces</option>
                        <option value="Armed Forces Pacific">Armed Forces Pacific</option>
                        <option value="Alabama">Alabama</option>
                        <option value="Alaska">Alaska</option>
                        <option value="Arizona">Arizona</option>
                        <option value="Arkansas">Arkansas</option>
                        <option value="California">California</option>
                        <option value="Colorado">Colorado</option>
                        <option value="Connecticut">Connecticut</option>
                        <option value="District of Columbia">District of Columbia</option>
                        <option value="Delaware">Delaware</option>
                        <option value="Florida">Florida</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Guam">Guam</option>
                        <option value="Hawaii">Hawaii</option>
                        <option value="Idaho">Idaho</option>
                        <option value="Illinois">Illinois</option>
                        <option value="Indiana">Indiana</option>
                        <option value="Iowa">Iowa</option>
                        <option value="Kansas">Kansas</option>
                        <option value="Kentucky">Kentucky</option>
                        <option value="Louisiana">Louisiana</option>
                        <option value="Maine">Maine</option>
                        <option value="Maryland">Maryland</option>
                        <option value="Massachusetts">Massachusetts</option>
                        <option value="Michigan">Michigan</option>
                        <option value="Minnesota">Minnesota</option>
                        <option value="Mississippi">Mississippi</option>
                        <option value="Missouri">Missouri</option>
                        <option value="Montana">Montana</option>
                        <option value="Nebraska">Nebraska</option>
                        <option value="New Hampshire">New Hampshire</option>
                        <option value="New Jersey">New Jersey</option>
                        <option value="New Mexico">New Mexico</option>
                        <option value="New York">New York</option>
                        <option value="Nevada">Nevada</option>
                        <option value="North Carolina">North Carolina</option>
                        <option value="North Dakota">North Dakota</option>
                        <option value="Ohio">Ohio</option>
                        <option value="Oklahoma">Oklahoma</option>
                        <option value="Oregon">Oregon</option>
                        <option value="Pennsylvania">Pennsylvania</option>
                        <option value="Puerto Rico">Puerto Rico</option>
                        <option value="Rhode Island">Rhode Island</option>
                        <option value="South Carolina">South Carolina</option>
                        <option value="South Dakota">South Dakota</option>
                        <option value="Tennessee">Tennessee</option>
                        <option value="Texas">Texas</option>
                        <option value="Utah">Utah</option>
                        <option value="Vermont">Vermont</option>
                        <option value="Virgin Islands">Virgin Islands</option>
                        <option value="Virginia">Virginia</option>
                        <option value="Washington">Washington</option>
                        <option value="West Virginia">West Virginia</option>
                        <option value="Wisconsin">Wisconsin</option>
                        <option value="Wyoming">Wyoming</option>
                    </select>
                </div>
                <div class="form-group col-xs-4">
                    <input type="email" class="form-control" id="zipcode" placeholder="Zip Code" value="<?php echo $owner['zipcode']?>">
                </div>

                <div class="form-group col-xs-6">
                    <label for="Daytime Phone">Daytime Phone</label>
                    <input type="text" class="form-control" id="daytime_phone" placeholder="" value="<?php echo $owner['daytime_phone']?>">
                </div>

                <div class="form-group col-xs-6">
                    <label for="Cell Phone">Cell Phone</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="" value="<?php echo $owner['cell_phone']?>">
                </div>

                <div class="form-group col-xs-12">
                    <label for="Comments">Comments</label>
                    <textarea class="form-control" rows="3" placeholder="Enter ..."><?php echo $owner['comments']?></textarea>
                </div>
            </div>
            <!-- /.box-body -->

            <div class="box-footer">
                <button type="submit" class="btn btn-default" onclick="location.href='/owner_management'">Cancel</button>
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
        </div>
</section>
<!-- /.content -->