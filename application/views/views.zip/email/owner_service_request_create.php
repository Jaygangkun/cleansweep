<html>
<body>
Your cleaning request has been received by our office. Your property will be serviced on the date designated. Should we have any further questions, we will contact you. Please notify our office immediately if there are any changes. <br><br>
For all cancellations a required 48 hour notice is mandatory to avoid a trip charge.<br><br>
Thank you so much for your business! <br><br><br><br><br>
Clean Sweep HHI<br>
P.O. Box 7244<br>
Hilton Head Island, SC 29938<br>
<a href="mailto:info@cleansweephhi.com">info@cleansweephhi.com</a><br>
OFC: (843)-689-9178<br>

</body>
</html>