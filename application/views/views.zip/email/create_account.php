<html>
<body>
Account Name: <?php echo $username;?><br><br>
Account Password: <?php echo $password;?>
</body>
</html>